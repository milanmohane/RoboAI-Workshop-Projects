import numpy as np
import matplotlib.pyplot as plt

# 1. Define Gait Parameters (From Question 4)
T = 4.0  # Gait cycle time in seconds
t = np.linspace(0, T, 100)  # Time vector from 0 to T

# 2. Kinematic Equations
# Hip swings between -30 and +30 degrees
hip_angle = 30 * np.sin(2 * np.pi * t / T)

# Knee bends up to 60 degrees during swing, stays at 0 during stance
knee_angle = 60 * np.maximum(0, np.sin(2 * np.pi * t / T))

# 3. Plotting the Trajectories
plt.figure(figsize=(10, 5))
plt.plot(t, hip_angle, label='Hip Angle (degrees)', color='blue', linewidth=2)
plt.plot(t, knee_angle, label='Knee Angle (degrees)', color='orange', linewidth=2)

# Formatting the graph for your report
plt.title('Joint Trajectory for One Gait Cycle (One Leg)')
plt.xlabel('Time (seconds)')
plt.ylabel('Angle (degrees)')
plt.axhline(0, color='black', linewidth=1, linestyle='--')
plt.grid(True)
plt.legend()
plt.tight_layout()

# Save the plot
plt.savefig('Question5_Gait_Plot.png')
plt.show()