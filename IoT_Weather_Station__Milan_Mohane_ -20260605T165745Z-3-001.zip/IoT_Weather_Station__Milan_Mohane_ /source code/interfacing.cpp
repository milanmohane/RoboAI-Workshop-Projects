#include <WiFi.h>
#include <DHT.h>

const char* ssid = "Milan";
const char* password = "milan572";
const char* server = "api.thingspeak.com";
String apiKey = "XSBS8NFPPGFBWB0U";

#define DHTPIN 4
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);
WiFiClient client;
void setup() {
  Serial.begin(115200);
  dht.begin();

  connectWiFi();
}
void connectWiFi() {
  Serial.print("Connecting to WiFi");
  Serial.println(ssid);
  WiFi.begin(ssid, password);
  int retries = 0;
  while (WiFi.status() != WL_CONNECTED && retries < 20) {
    delay(500);
    retries++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi Connected");
  } else {
    Serial.println("\nWiFi Connection Failed");
  }
}

void loop() {

  if (WiFi.status() != WL_CONNECTED) {;
    connectWiFi();
  }

  float temp = dht.readTemperature();
  float hum = dht.readHumidity();

  if (isnan(temp)||isnan(hum)) {
    Serial.println("Sensor read failed");
    delay(2000);
    return;
  }

  Serial.println("Sensor Data");
  Serial.print("Temperature: ");
  Serial.print(temp);
  Serial.println("°C");

  Serial.print("Humidity: ");
  Serial.print(hum);
  Serial.println("%");

  if(client.connect(server,80)){
    String url = "/update?api_key=" + apiKey +"&field1=" + String(temp) +"&field2=" + String(hum);
    client.print("GET " + url + " HTTP/1.1\r\n" +String("Host: ") + server + "\r\n" +"Connection: close\r\n\r\n");
    Serial.println("Data sent to ThingSpeak");
  } 
  else{
    Serial.println("Connection to ThingSpeak failed");
  }
  client.stop();
  delay(15000);
}

