readChannelID = 3317946; 
readAPIKey = '9B1WO80NZZT3HPOX';

data = thingSpeakRead(readChannelID,'Fields',[1, 2],'ReadKey',readAPIKey);

tempThreshold = 35;
humThreshold = 80;  

if ~isempty(data)
    tempData = data(1); 
    humData = data(2);  
    
    alertNeeded = false;
    alertReason = '';
    
    if tempData > tempThreshold && humData > humThreshold
        alertNeeded = true;
        alertReason = sprintf('BOTH Temperature (%.2f °C) and Humidity (%.2f %%) are too high!',tempData,humData);
    elseif tempData > tempThreshold
        alertNeeded = true;
        alertReason = sprintf('Temperature (%.2f °C) is above the %d °C limit.',tempData,tempThreshold);
    elseif humData > humThreshold
        alertNeeded = true;
        alertReason = sprintf('Humidity (%.2f %%) is above the %d %% limit.',humData,humThreshold);
    end
    
    if alertNeeded
        alertApiKey = 'TAKIMXBUqhBHj1Uk6fu';
        
        alertSubject = 'Weather Station Alert: Threshold Exceeded!';
        
        alertBody = sprintf('Warning!\n\n%s\n\nCurrent Readings:\nTemperature: %.2f °C\nHumidity: %.2f %%', alertReason, tempData, humData);
        
        alertUrl = 'https://api.thingspeak.com/alerts/send';
        options = weboptions('HeaderFields',{'ThingSpeak-Alerts-API-Key',alertApiKey});
        
        try
            webwrite(alertUrl,'subject',alertSubject,'body',alertBody,options);
            disp('Alert email sent successfully.');
        catch exception
            disp(['Error sending alert: ',exception.message]);
        end
    else
        disp('Readings are within normal limits. No email sent.');
    end
else
    disp('No data found in the channel.');
end